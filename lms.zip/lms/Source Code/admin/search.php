<html>
<head>
</head>
<body>
<h2>Search the Exercise Tables</h2>
<form action="back.php" method="post">
  Search For:
  <input name="searchquery" type="text" size="44" maxlength="88"> 
  Within: 
  <select name="filter1">
    <option value="ALL">ALL</option>
    <option value="BOOKS">BOOKS</option>
    <option value="AUTHOR">AUTHOR</option>
  </select>
  <input name="myBtn" type="submit">
  <br>
</form>
</body>
</html>